<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<div id="frm_adv_info" class="postbox">
	<div class="inside">
		<?php FrmFormsController::mb_tags_box( $id ); ?>
	</div>
</div>
