<?php

class Backend_model extends CI_Model{	

	public function _insert($data, $table){
		$this->db->insert($table, $data);
		// return $this->db->get_compiled_select();
		 // echo $this->db->last_query();
		return $this->db->affected_rows();
	}

	public function _insertwhere($data, $where, $table){
		$this->db->where($where);
		$this->db->insert($table, $data);
		// return $this->db->get_compiled_select();
		 // echo $this->db->last_query();
		return $this->db->affected_rows();
	}

	public function _update($data, $where, $table){
		$this->db->where($where);
		$this->db->update($table, $data);
		// echo $this->db->last_query();
		return $this->db->affected_rows();
	}

	public function _delete($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
		// return $this->db->get_compiled_select();
		 // echo $this->db->last_query();
		return $this->db->affected_rows();
	}
	

	public function _get($table, $where = null){
		return $this->db->get_where($table, $where)->result();
		//return $this->db->last_query(); 

	}
	// public function _join()
	// {
	// 	$this->db->join($table, $table.$column = $table2.$column2);
	// }

	public function _query($qry){
		return $this->db->query($qry)->result();
		// echo$this->db->last_query(); 
	}
	public function insert_query($qry){
		$this->db->query($qry);
		return $this->db->affected_rows();
		// echo$this->db->last_query(); 
	}

	public function get_last_insert_id($table){
		$this->db->select($table."_SEQUENCE.NEXTVAL AS NEXTID",FALSE);
    	$this->db->from($table);
		$query = $this->db->get();
		$row = $query->row();
		//return $row->NEXTID;
		return $this->db->last_query(); 
	}

	// public function charges($HAWB_NO){
	// 	$result = $this->db->query("")
	// }
}

?>